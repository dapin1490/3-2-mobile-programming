package com.example.mid2;

public class MyItem {
    String name, phone, email;

    public MyItem(String name, String phone, String email) {
        this.name = name;
        this.phone = phone;
        this.email = email;
    }
}

package com.example.baseadapterdemo;

public class MyItem {
    int icon;
    String name;

    public MyItem(int icon, String name) {
        this.icon = icon;
        this.name = name;
    }
}

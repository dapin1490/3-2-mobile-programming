package andexam.ver6.c05_layout;

import andexam.ver6.*;
import android.app.*;
import android.os.*;

public class NameCard extends Activity {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.namecard);
	}
}